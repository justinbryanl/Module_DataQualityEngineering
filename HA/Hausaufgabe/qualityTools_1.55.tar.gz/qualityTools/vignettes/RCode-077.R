Stangle(file="qualityTools.rnw", output="RCode.r", annotate=FALSE) 


