###################################################
### code chunk number 78: qualityTools.rnw:1102-1103
###################################################
Stangle(file="qualityTools.rnw", output="RCode.r", annotate=FALSE) 


