versuchsplan_ui <- function(id) {
  ns <- NS(id)
  
  tagList(
    data_selector_ui(
      id = ns("id_data_selector")
    ),
    actionButtonQW(
      inputId = ns("add_histogram"),
      label = "Show Histogram",
      icon = icon("area-chart"),
      tooltip = "Öffne Histogramm"
    ),
    actionButtonQW(
      inputId = ns("add_effectplot"),
      label = "Show Effect Plot",
      icon = icon("area-chart"),
      tooltip = "Öffne Effect Plot"
    ),
    actionButtonQW(
      inputId = ns("add_InteractionPlot"),
      label = "Show Intercation Plot",
      icon = icon("area-chart"),
      tooltip = "Öffne Interaction Plot"
    ),
    actionButtonQW(
      inputId = ns("add_ParetoPlot"),
      label = "Show Pareto Plot",
      icon = icon("area-chart"),
      tooltip = "Öffne Pareto Plot"
    ),
    actionButtonQW(
      inputId = ns("add_ContourPlot"),
      label = "Show Contour Plot",
      icon = icon("area-chart"),
      tooltip = "Öffne Contour Plot"
    ),
    actionButtonQW(
      inputId = ns("add_SurfacePlot"),
      label = "Show Surface Plot",
      icon = icon("area-chart"),
      tooltip = "Öffne Surface Plot"
    ),
    selectInput(
      inputId = ns("add_selected_effectplot"),
      label = "Choose data for Effect Plot",
      choices = c("Flügellänge","Körperlänge", "Einschnitt", "Papierstärke")
    )
  )
}

versuchsplan_server <- function(id, .values) {

  moduleServer(
    id, 
    function(input, output, session) {
      ns <- session$ns
      
      data_r <- reactive({
        data_selector_return$data_r()
      })
      
      our_data <- reactive({data<- data_r()})
      
#Histogram      
      histogram_r <- reactive({
        ggplot(data = our_data(), mapping = aes(x = Flugdauer)) +
          geom_histogram(bins = nclass.Sturges(our_data()$Flugdauer)) +
          theme_bw()
      })
      
      observeEvent(input$add_histogram, {
        plot_output_id <- paste0("histogram_", data_selector_return$name_r())
        
        .values$viewer$append_tab(
          tab = tabPanel(
            title = paste("Histogram:", data_selector_return$name_r()),
            value = paste0("histogram_", data_selector_return$name_r()),
            plotOutput(
              outputId = ns(plot_output_id)
            )
          )
        )
        
        if (!hasName(output, plot_output_id)) {
          output[[plot_output_id]] <- renderPlot({
            histogram_r()
          })
        }
      })
#Effect Plot   (masih salah grgr belom ada yang automatisierung data ke ABCD)   
      
     effectplot_r <- reactive({
       
       vp <- facDesign(
         k = 4,
         replicates = 2,
         centerCube = 16
       )

       names(vp) <- c("Fluegellaenge", "Koerperlaenge", "Einschnitt", "Papierart")
       lows(vp) <- c(60, 50, 0, 80)
       highs(vp) <- c(90, 100, 60, 120)
       units(vp) <- c("mm", "mm", "mm", "g/mm^2")

       vp_df_mitrunorder_df_sortiert <- as.data.frame(vp)
       vp_df_mitrunorder_tibble_sortiert <- as_tibble(vp_df_mitrunorder_df_sortiert)
       
       vp_sortiert_gamma <- vp_df_mitrunorder_tibble_sortiert %>% 
         arrange(D) %>% 
         arrange(C) %>% 
         arrange(B) %>% 
         arrange(A)

       vp_masuk <- our_data() %>% 
         arrange(Papierstaerke) %>%
         arrange(Einschnitt) %>% 
         arrange(Koerperlaenge) %>% 
         arrange(Fluegellaenge)

       vp_sortiert_gamma <- vp_sortiert_gamma %>% mutate(Flugdauer = vp_masuk$Flugdauer)
       vp_sortiert_gamma <- vp_sortiert_gamma %>% arrange(RunOrder)

       Flugdauer <- vp_sortiert_gamma$Flugdauer
       response(vp)<- Flugdauer

       hw_macem2 <- vp_df_mitrunorder_tibble_sortiert %>%
         group_by(A) %>% 
         summarise(mean = mean(response))
       
       ggplot(data = hw_macem2, mapping = aes(x = A, y = mean)) + 
         geom_point(col = "red") + 
         geom_line() + 
         theme_bw() + 
         theme(plot.title = element_text(hjust = 0.5),
              panel.border = element_blank()) +
        labs(x = "A: Flügellänge", y = "Flugdauer", title = "Effekt-Plot")
      
      })
      observeEvent(input$add_effectplot, {
        plot_output_id <- paste0("effectplot_", data_selector_return$name_r())
        
        .values$viewer$append_tab(
          tab = tabPanel(
            title = paste("Effect Plot:", data_selector_return$name_r()),
            value = paste0("effectplot_", data_selector_return$name_r()),
            plotOutput(
              outputId = ns(plot_output_id)
            )
          )
        )
        
        if (!hasName(output, plot_output_id)) {
          output[[plot_output_id]] <- renderPlot({
            effectplot_r()
          })
        }
      })
      
# #Interaction Plot
#       interactionplot_r <- reactive({
#         ggplot(data = data_r(), mapping = aes(x = Flugdauer)) +
#           geom_histogram(bins = nclass.Sturges(our_data()$Flugdauer)) +
#           theme_bw()
#       })
#       
#       observeEvent(input$add_histogram, {
#         plot_output_id <- paste0("histogram_", data_selector_return$name_r())
#         
#         .values$viewer$append_tab(
#           tab = tabPanel(
#             title = paste("Histogram:", data_selector_return$name_r()),
#             value = paste0("histogram_", data_selector_return$name_r()),
#             plotOutput(
#               outputId = ns(plot_output_id)
#             )
#           )
#         )
#         
#         if (!hasName(output, plot_output_id)) {
#           output[[plot_output_id]] <- renderPlot({
#             histogram_r()
#           })
#         }
#       })

    #   defect <- reactive({ c(27, 789, 9, 65, 12, 109, 30, 15, 45, 621)
    #   })
    #   
    #   # x axis titles
    #   names(defect) <- reactive({ c("Too noisy", "Overpriced", "Food not fresh", 
    #                      "Food is tasteless", "Unfriendly staff",
    #                      "Wait time", "Not clean", "Food is too salty", 
    #                      "No atmosphere", "Small portions") 
    #   
    # 
    #   })
    #   paretoplot_r <- reactive({pareto.chart(defect, xlab = "Categories", # x-axis label
    #                                         ylab="Frequency",  # label y left
    #                                         
    #                                         # colors of the chart             
    #                                         col=heat.colors(length(defect)), 
    #                                         
    #                                         # ranges of the percentages at the right
    #                                         cumperc = seq(0, 100, by = 20),  
    #                                         
    #                                         # label y right
    #                                         ylab2 = "Cumulative Percentage", 
    #                                         
    #                                         # title of the chart
    #                                         main = "Complaints of different customers" 
    #   )
    # })
    #   
    #   observeEvent(input$add_pareto, {
    #     plot_output_id <- paste0("paretoplot_", data_selector_return$name_r())
    #     
    #     .values$viewer$append_tab(
    #       tab = tabPanel(
    #         title = paste("Pareto Plot:", data_selector_return$name_r()),
    #         value = paste0("paretoplot_", data_selector_return$name_r()),
    #         plotOutput(
    #           outputId = ns(plot_output_id)
    #         )
    #       )
    #     )
    #     
    #     if (!hasName(output, plot_output_id)) {
    #       output[[plot_output_id]] <- renderPlot({
    #         paretoplot_r()
    #       })
    #     }
    #   })
      
      data_selector_return <- data_selector_server(
        id = "id_data_selector",
        .values = .values
      )
    }
  )  
}